/*
 *
 * Copyright 2015 gRPC authors.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 */

/*
 * This is a dummy file to provide an invalid specialized_wakeup_fd_vtable on
 * systems without anything better than pipe.
 */

#include <grpc/support/port_platform.h>

#include "src/core/lib/iomgr/port.h"

#ifdef GRPC_POSIX_NO_SPECIAL_WAKEUP_FD

#include <stddef.h>
#include "src/core/lib/iomgr/wakeup_fd_posix.h"

static int check_availability_invalid(void) { return 0; }

const grpc_wakeup_fd_vtable grpc_specialized_wakeup_fd_vtable = {
    nullptr, nullptr, nullptr, nullptr, check_availability_invalid};

#endif /* GRPC_POSIX_NO_SPECIAL_WAKEUP_FD */
